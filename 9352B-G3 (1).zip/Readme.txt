Good day sir,
Sorry for the inconvience we failed to recheck the link to our CSS files in our HTML thus the links to our CSS files are inconsistent
for the 9352B-G3-1 folder the index.html uses styles/styles.css as its link
for the 9352B-G3-2 folder the index.html uses Style/style.css as its link
for the 9352B-G3-3 folder the index.html uses styles/style.css as its link